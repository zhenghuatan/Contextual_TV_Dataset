from itertools import compress
import datetime as dt
import numpy as np
import copy
import csv

def read_user_data(fp):
# def read_user_data(fp,act_users):
    """Reads the user info from the csv file.
    Input: filename, list of active users
    Output: Array of users
    """
    user = []
    with open(fp, 'r') as f:
        reader = csv.reader(f, delimiter=';')
        next(reader, None) #Skip header
        for row in reader:
            # if(int(row[0]) in act_users):
            row[0] = int(row[0])                                 #User ID 
            row[1] = int(row[1])                                 #Language
            row[2] = dt.datetime.strptime(row[2], '%Y-%m-%d %X') #Creation date/time
            row[3] = int(row[3]) if row[3]!='' else None         #Gender
            row[4] = int(row[4]) if row[4]!='' else None         #Age group
            row[5] = int(row[5]) if row[5]!='' else None         #Device
            row[6] = int(row[6]) if row[6]!='' else None         #Household_1
            row[7] = row[7].split(',') if row[7]!='' else None   #Household_2
            row[8] = int(row[8]) if row[8]!='' else None         #TV_1
            row[9] = row[9].split(',') if row[9]!='' else None   #TV_2
            user.append(row)
    # Get columns in ans with list(zip(*ans))[0]
    return user

def read_answers_csv(fp):
    """Reads the answers from the csv file.
    Input: filename
    Output: Array of answers
    """
    ans = []
    with open(fp, 'r') as f:
        reader = csv.reader(f, delimiter=';')
        next(reader, None) #Skip header
        for row in reader:
            row[0] = int(row[0])                                 #Answer ID 
            row[1] = int(row[1])                                 #User ID 
            row[2] = dt.datetime.strptime(row[2], '%Y-%m-%d %X') #Date/time
            row[3] = True if row[3]=='2' else False              #q1 Yes/no
            row[4] = row[4].split(',') if row[4]!='' else None   #q2 Who
            row[5] = int(row[5]) if row[5]!='' else None         #q3 Many
            row[6] = row[6].split(',') if row[6]!='' else None   #q4 What
            row[7] = row[7].split(',') if row[7]!='' else None   #q5 Where
            row[8] = int(row[8]) if row[8]!='' else None         #q6 Aware
            ans.append(row)
    # Get columns in ans with list(zip(*ans))[0]
    return ans

def get_yes_answers(ans):
    """Returns answers where TV has been watched
    Input: Answers
    Output: Yes answers
    """
    ansy = copy.deepcopy(ans)
    return(list(compress(ansy, [v[3] is True for v in ansy])))

def clean_answers_for_text(answ):
    """Returns answers without the optional text
    Input: Answers
    Output: Answers without text
    """
    answers = copy.deepcopy(answ)
    max_val=[0,0,0,0,7,0,9,7,0]
    for ans in answers:
        #Look at q2 (who), q4 (what), and q5 (where)
        for j in [4,6,7]:
            if(ans[j] is not None):
                for i in range(len(ans[j])):
                    if(ans[j][i]=='x'):
                        #Make 'x' (other) the largest option
                        ans[j][i] = max_val[j] + 1
                        #Remove text when other is answered
                        for k in range(i+1,len(ans[j])):
                            ans[j].pop(i+1)
                        break
                    elif(len(ans[j][i]) == 1):
                        #Convert string to int
                        ans[j][i] = int(ans[j][i])
    return answers

def split_answers(answ):
    """Splits answers with multiple genres (q4)
    Input: Answers
    Output: Splitted answers
    """
    answers = copy.deepcopy(answ)
    j = 0
    for i in range(len(answers)):
        if(answers[j][6] is not None):
            #If multiple genres have been answered
            if(len(answers[j][6])>1):
                ans = answers[j]*1
                temp_w = answers[j][6]*1
                answers[j][6] = temp_w[0]*1
                #Insert each genre with similar context
                for k in range(1,len(temp_w)):
                    ans[6] = temp_w[k]*1
                    answers.insert(j+1,ans*1)
                    j+=1
            elif(len(answers[j][6])==1):
                answers[j][6] = answers[j][6][0]
        j+=1
    return answers

def make_feat_vec(ans):
    """Convert raw answer to feature vector."""
    vec = []
    for i in range(len(ans)):
        if ans[i][6] is not None:
            temp = []
            #Label/genre
            temp.append(ans[i][6])
            #User ID
            temp.append(ans[i][1]*1)
            #Time (Morning, Noon, Afternoon, Evening, Night)
            temp.append(time_of_day(ans[i][2]))
            #Day (weekday, weekend)
            temp.append(weekday_end(ans[i][2]))
            #Who, how many, service, awareness
            for j in [4,5,7,8]:
                if ans[i][j] is not None:
                    temp.append(ans[i][j])
                else:
                    temp.append(None)
            vec.append(temp)
    return vec

def get_active_users(ans,K=5):
    #Get User ID for each answer
    ans_userid = list(zip(*ans))[1]
    ans_user = [0]*(max(ans_userid)+1)
    answ = []
    active_users = []
    #Loop users
    for i in range(len(ans_user)):
        temp = copy.deepcopy(ans_userid)
        #Get answers submitted by user i
        temp = np.array(temp)==i
        ans_user[i] = list(compress(ans, temp)) 
        #If the user has submitted at least K answers
        if(len(ans_user[i])>=K):
            active_users.append(i)
            for it in ans_user[i]:
                answ.append(it)
    return answ, active_users

def time_of_day(ts):
    """Bin the timestamp into five (morning,noon,afternoon,evening,night)."""
    h=ts.hour
    t=0
    #Morning
    if(h >= 6 and h <= 9):
        t=1
    #Noon
    elif(h > 9 and h <= 13):
        t=2
    #Afternoon
    elif(h > 13 and h <= 17):
        t=3
    #Evening
    elif(h > 17 and h <= 21):
        t=4
    #Night
    else:
        t=5
    return t

def weekday_end(ts):
    """Bin the timestamp into two (weekday,weekend)."""
    weekday = ts.weekday() #Monday == 0 ... Sunday == 6
    t=0
    if(weekday<5): #Split to weekday / weekend
        t=1
    else:
        t=2
    return t
