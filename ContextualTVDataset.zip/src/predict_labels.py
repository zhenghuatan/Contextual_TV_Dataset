"""Functions for predicting labels."""
from sklearn.model_selection import GridSearchCV, KFold, cross_validate, cross_val_predict
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neural_network import MLPClassifier
from sklearn.svm import SVC
from scipy.stats.distributions import chi2
import sklearn.metrics as slmet
import matplotlib.pyplot as plt
from itertools import compress
import seaborn as sns
import pandas as pd
import numpy as np
import warnings 
warnings.filterwarnings("ignore") #Bad practise to ignore all warnings
import copy

import src.config as cf

def predict_labels(answers, active_users, features, methods, metrics):
    if(len(cf.MCNEMAR_TESTS)>0):
        cf.MCNEMAR_YS    = [[None, None] for i in range(len(cf.MCNEMAR_TESTS))]
        cf.MCNEMAR_GTS   = [[None, None] for i in range(len(cf.MCNEMAR_TESTS))]
    res = [[[0 for k in range(len(metrics))] 
               for j in range(len(features))] 
               for i in range(len(methods))]
    for i in range(len(methods)):
        for j in range(len(features)):
            #Print information
            print('--------------------------')
            print('Running method:',methods[i],
                  '\nFeature configuration:',features[j])
            #Run prediction
            res[i][j] = prediction_handler(answers, active_users, 
                                           features[j], methods[i], metrics)
            #Compute and print mean and std. dev. of scores
            for k in range(len(metrics)):
                print('Result ('+metrics[k]+'): '+
                      '{0:.3f} ({1:.3f})'.format(
                         np.mean(res[i][j][k]),
                         np.std(res[i][j][k])))
    print('--------------------------')
    #Plot the results
    if(cf.SHOW_FIGS or cf.SAVE_FIGS):
        save_plot(res,methods,features,metrics)
    #McNemar's test
    mcnemar_test()

def prediction_handler(answers, active_users, feature, method, metrics):
    #Get one hot encoded feature vectors
    ans, active_feat = one_hot_encoding(answers, active_users, feature)
    #Get labels
    lab = list(zip(*answers))[0]
    conf_mat_name = method + '_' + feature
    #Call method
    if method=='LR' or method=='GBDT' or method=='SVM' or method=='MLP':
        res = sl_predict(ans, lab, method, metrics, conf_mat_name)
    elif method=='LRTF':
        res = tf_predict(ans, lab, method, metrics, conf_mat_name)
    elif method=='random':
        res = random_predict(lab, metrics)
    elif method=='toppop':
        res = toppop_predict(lab, metrics)
    return res

def one_hot_encoding(answers, active_users, feature):
    ans = copy.deepcopy(answers)
    act_feat = read_feat_as_string(feature)
    user_map = make_user_mapping(active_users)
    # Number of possible values each feature can take on
    n_vals = [0, len(active_users), 5, 2, 8, 5, 8, 5] 
    n_vals = list(compress(n_vals,act_feat))
    for i in range(len(answers)):
        one_hot = np.zeros((1,sum(n_vals)))[0]
        temp = 0
        for j in range(len(answers[i])):
            if act_feat[j]:
                if answers[i][j] is not None:
                    if j==1:
                        one_hot[user_map[answers[i][j]]] = 1
                    else:
                        try:
                            for it in answers[i][j]:
                                one_hot[it+sum(n_vals[:temp])-1] = 1
                        except:
                            one_hot[answers[i][j]+sum(n_vals[:temp])-1] = 1
                temp += 1
        ans[i] = one_hot
    return ans, n_vals

def read_feat_as_string(fs):
    fs1 = ''
    fs2 = ''
    fss = ''
    if '-' in fs:
        fs1,fs2 = fs.split('-')
    elif fs == 'all+S':
        fss = 'UTDWMSA'
    else:
        fs1 = fs*1
    if 'U' in fs1: 
        fss += 'U'
    if 'T' in fs1:
        fss += 'T'
    if 'D' in fs1:
        fss += 'D'
    if 'W' in fs1:
        fss += 'W'
    if 'M' in fs1:
        fss += 'M'
    if 'S' in fs1:
        fss += 'S'
    if 'A' in fs1:
        fss += 'A'
    if 'all' in fs1:
        fss = 'UTDWMA'
    if fs2 != '':
        for c in fs2:
            ind = fss.find(c)
            if ind!=-1:
                fss = fss[:ind] + fss[ind+1:]
    active = [False for i in range(8)]
    if 'U' in fss: 
        active[1]=True
    if 'T' in fss:
        active[2]=True
    if 'D' in fss:
        active[3]=True
    if 'W' in fss:
        active[4]=True
    if 'M' in fss:
        active[5]=True
    if 'S' in fss:
        active[6]=True
    if 'A' in fss:
        active[7]=True
    return active

def make_user_mapping(act_user):
    ind = 0
    user_map = [None for i in range(150)]
    for i in range(150):
        if i in act_user:
            user_map[i] = ind
            ind += 1
    return user_map

def sl_predict(x, y, method, metrics, conf_mat_name):
    if method == 'LR':
        estimator = LogisticRegression(solver='sag', multi_class='multinomial',
                                       max_iter=1000)
        p_grid = {'C': [0.1, 1, 10, 100]}
    elif method == 'GBDT':
        estimator = GradientBoostingClassifier(subsample=0.5,learning_rate=0.01,n_estimators=1000)
        p_grid = {'max_depth': [1, 2]}
    elif method == 'SVM':
        estimator = SVC(decision_function_shape='ovr', cache_size=4096)
        p_grid = [{'kernel':['rbf'], 'gamma':['auto',1e-3,1e-4], 'C':[1,10,100,1000]},
                  {'kernel': ['linear'], 'C': [1,10,100,1000]}]
    elif method == 'MLP':
        estimator = MLPClassifier(hidden_layer_sizes=(200,200), activation='relu', solver='adam')
        p_grid = {'alpha': [0.01, 0.1, 1]}

    inner_cv = KFold(n_splits=3,shuffle=True)
    outer_cv = KFold(n_splits=5,shuffle=True)

    clf = GridSearchCV(estimator=estimator, param_grid=p_grid, cv=inner_cv,
                       scoring='accuracy', n_jobs=6)
    clf.fit(x,y)

    # Print result of tuning hyper-parameters
    print("Best parameter set:")
    print(clf.best_params_)
    print("Grid scores for parameters:")
    means = clf.cv_results_['mean_test_score']
    stds = clf.cv_results_['std_test_score']
    for mean, std, params in zip(means, stds, clf.cv_results_['params']):
        print("%0.3f (+/-%0.03f) for %r"
              % (mean, std * 2, params))

    if hasattr(clf, 'decision_function'):
        pred_method = 'decision_function'
    else:
        pred_method = 'predict_proba'
    y_pred = cross_val_predict(clf, x, y, cv=outer_cv, n_jobs=6, method=pred_method)

    #Change this line if you want to save a confusion matrix for 
    #other methods or feature configurations, check filename in save_confmat()
    if conf_mat_name == 'LR_all':
        if(cf.SHOW_FIGS or cf.SAVE_CONFMAT):
            save_confmat(y,y_pred,conf_mat_name)

    for i in range(len(cf.MCNEMAR_TESTS)):
        for j in range(2):
            if(conf_mat_name==cf.MCNEMAR_TESTS[i][j]):
                cf.MCNEMAR_YS[i][j]  = y_pred
                cf.MCNEMAR_GTS[i][j] = y

    scores = []
    for outer_ind_trn, outer_ind_tst in outer_cv.split(x):
        ind_test    = [it in outer_ind_tst for it in range(len(y))]
        y_test      = np.array(list(compress(y,ind_test)))
        y_pred_test = np.array(list(compress(y_pred,ind_test)))
        scores.append(get_score(y_test,y_pred_test,metrics))
    res = []
    for i in range(len(metrics)):
        res.append(list(zip(*scores))[i])
    return res

def random_predict(y, metrics):
    outer_cv = KFold(n_splits=5,shuffle=True)
    scores = []
    for outer_ind_trn, outer_ind_tst in outer_cv.split(y):
        ind_tst = [it in outer_ind_tst for it in range(len(y))]
        y_test = np.array(list(compress(y,ind_tst)))
        # y_pred = np.random.choice(range(1,11),(len(y),1))
        y_pred = []
        for i in range(len(y_test)):
            y_pred.append(np.random.choice(range(1,11),10,replace=False))
        scores.append(get_score(y_test,y_pred,metrics))
    res = []
    for i in range(len(metrics)):
        res.append(list(zip(*scores))[i])
    return res

def toppop_predict(y, metrics):
    outer_cv = KFold(n_splits=5,shuffle=True)
    scores = []
    for outer_ind_trn, outer_ind_tst in outer_cv.split(y):
        ind_trn = [it in outer_ind_trn for it in range(len(y))]
        ind_tst = [it in outer_ind_tst for it in range(len(y))]
        y_train = list(compress(y,ind_trn))
        y_test  = np.array(list(compress(y,ind_tst)))
        C_train = []
        for i in range(1,11):
            C_train.append(y_train.count(i))
        y_pred  = np.ones((len(y_test),1))*C_train
        scores.append(get_score(y_test,y_pred,metrics))
    res = []
    for i in range(len(metrics)):
        res.append(list(zip(*scores))[i])
    return res

def get_score(y_gt,y_pred,metrics):
    y_pred_1 = np.argmax(y_pred,axis=1)+np.ones(len(y_pred))
    res = []
    for met in metrics:
        if met=='A@1':
            res.append(slmet.accuracy_score(y_gt,y_pred_1))
        elif met=='F1 (macro)':
            res.append(slmet.f1_score(y_gt,y_pred_1,average='macro'))
        elif met=='A@3':
            res.append(get_accuracy(y_gt,y_pred,3))
        elif met=='MRR':
            res.append(get_mrr(y_gt,y_pred))
    return res

def save_confmat(y,y_pred,conf_mat_name):
    y_pred_1 = np.argmax(y_pred,axis=1)+np.ones(len(y_pred))
    conf_mat = slmet.confusion_matrix(y,y_pred_1)
    c2 = np.zeros((13,13))
    c2[:-3,:-3]=conf_mat
    c2[:,-3] = np.sum(c2,axis=1)
    c2[-3,:] = np.sum(c2,axis=0)
    for i in range(conf_mat.shape[0]):
        c2[i,-2] = c2[i,i] / c2[i,-3]
        c2[-2,i] = c2[i,i] / c2[-3,i]
        c2[-1,i] = 2*c2[-2,i]*c2[i,-2]/(c2[-2,i]+c2[i,-2])
    for i in range(1,4):
        for j in range(1,3):
            c2[-i,-j] = None
            c2[-j,-i] = None
    for i in range(c2.shape[0]):
        c2[i,-1] = None

    class_names = ['News', 'Sport', 'Movie', 'Series', 'Music', 'Doc', 'Entert', 'Child', 'User', 'Other', 'Sum', 'Prec/Rec', 'F1']
    df_cm = pd.DataFrame(c2, index = [i for i in class_names], columns = [i for i in class_names])
    sns.set()
    with sns.axes_style('white'):
        p = sns.heatmap(df_cm, annot=True, vmin=0, vmax=100, cbar=False, cmap='Blues', fmt='g')
    for t in p.texts:
        tt = t.get_text()
        if(len(tt)>1):
            if(tt[1]=='.'):
                t.set_text('{0:.2f}'.format(float(tt)))
    labels = [item.get_text() for item in p.get_xticklabels()]
    labels[-2] = 'Recall'
    labels[-1] = ''
    p.set_xticklabels(labels)
    labels = [item.get_text() for item in p.get_yticklabels()]
    labels[-2] = 'Prec'
    p.set_yticklabels(labels)
    plt.yticks(rotation=0)
    plt.xlabel('Predicted\n', fontweight='bold')
    plt.ylabel('Observed\n', fontweight='bold')
    p.xaxis.set_ticks_position('top')
    p.xaxis.set_label_position('top')
    ax1 = p.axes
    ax1.set_position([0.12, 0.01, 0.95, 0.87])
    ax1.hlines([10, 11, 12], [0]*3, [11, 11, 10])
    ax1.vlines([10, 11], [0]*2, [11, 11])
    pcf = plt.gcf()
    pcf.set_figwidth(8)
    pcf.set_figheight(5)
    if cf.SAVE_CONFMAT:
        plt.savefig('img/fig7.pdf')
        # plt.savefig('img/confmat_'+conf_mat_name+'.pdf')
    if cf.SHOW_FIGS:
        plt.show()
    else:
        plt.close('all')

def save_plot(res,methods,features,metrics):
    sns.set()
    sns.set_style("ticks")
    sns.set_context(rc={"lines.linewidth": 1.0})
    colorp = [cf.r, cf.g, cf.b]
    rows = []
    for i in range(len(methods)):
        for j in range(len(features)):
            for k in range(len(metrics)):
                for l in range(5):
                    rows.append([methods[i], metrics[k], features[j], res[i][j][k][l]])
    df = pd.DataFrame.from_records(rows,columns=['method', 'metric', 'feat', 'res'])

    for met in metrics:
        temp_df = df.loc[df['metric'] == met]
        with sns.color_palette("Blues_d"):
            p = sns.barplot(x='feat',y='res',hue='method',data=temp_df,ci='sd')
        ax1 = p.axes
        ax1.legend(fontsize=14)
        ax1.set_xlim([-0.5, len(features)-0.5])
        ax1.set_yticks([i/10 for i in range(0,11)])
        if met == 'A@1' or met == 'F1 (macro)':
            ax1.set_ylim([0, 0.6])
        else:
            ax1.set_ylim([0, 1.0])
        ax1.set_xlabel('Feature configuration', fontweight='bold', fontsize=14)
        ax1.set_ylabel(met + ' score', fontweight='bold', fontsize=14)
        ax1.yaxis.grid()
        ax1.set_position([0.08, 0.13, 0.91, 0.84])
        sns.despine()
        plt.xticks(fontsize=14)
        plt.yticks(fontsize=14)
        pcf = plt.gcf()
        pcf.set_figwidth(10)
        pcf.set_figheight(5)
        if cf.SAVE_FIGS:
            plt.savefig('img/fig8_'+met+'.pdf')
        if cf.SHOW_FIGS:
            plt.show()
        else:
            plt.close('all')

def get_accuracy(gt,y_pred,k):
    t = []
    for i in range(len(gt)):
        p  = y_pred[i]
        sp = np.argsort(p)
        sp = sp[::-1]+np.ones(len(p))
        t.append(sp[:k])
    gt = np.array(gt)
    co = np.array([False]*len(gt))
    for i in range(len(t[0])):
        t1 = list(zip(*t))[i]
        er = gt - np.array(t1)
        co = co | (er==0)
    ac = sum(co)/len(co)
    return ac

def get_mrr(gt,y_pred):
    t=0
    for i in range(len(gt)):
        p  = y_pred[i]
        sp = np.argsort(p)
        sp = sp[::-1]+np.ones(len(p))
        for j in range(len(sp)):
            if(gt[i]==sp[j]):
                t += 1/(j+1)
    return t/len(gt)

def mcnemar_test():
    for i in range(len(cf.MCNEMAR_TESTS)):
        fc1   = cf.MCNEMAR_TESTS[i][0]
        y1    = cf.MCNEMAR_YS[i][0]
        y1    = np.argmax(y1,axis=1)+np.ones(len(y1))
        y1_gt = cf.MCNEMAR_GTS[i][0]
        fc2   = cf.MCNEMAR_TESTS[i][1]
        y2    = cf.MCNEMAR_YS[i][1]
        y2    = np.argmax(y2,axis=1)+np.ones(len(y2))
        y2_gt = cf.MCNEMAR_GTS[i][1]
        mat   = np.zeros((2,2))
        for i in range(len(y1)):
            a=0
            b=0
            if y1[i]!=y1_gt[i]:
                a=1
            if y2[i]!=y2_gt[i]:
                b=1
            mat[a,b] += 1
        mcnemars_chi_square = (mat[0,1]-mat[1,0])**2/(mat[0,1]+mat[1,0])
        mcnemars_p = chi2.sf(mcnemars_chi_square,1)
        #Compute Cramer's V based on the chi-square
        cramersV = np.sqrt(mcnemars_chi_square/(np.sum(mat)*(min(mat.shape)-1)))
        print("McNemar's test, FC1={}, FC2={}".format(fc1,fc2))
        print("McNemar's chi-square = {0:.3f}, df = {1:d}, p-value = {2:.4g}"
              .format(mcnemars_chi_square, 1, mcnemars_p))
        print("Cramer's V = {0:.3f}".format(cramersV))
        print('--------------------------')
