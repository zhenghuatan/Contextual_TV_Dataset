import matplotlib.pyplot as plt
import datetime as dt
import seaborn as sns
import pandas as pd
import numpy as np
import scipy

import src.config as cf

def fig1(ans, users):
    usercreated = list(zip(*users))[2]
    startDay = dt.datetime(2017,5,22,0,0)
    endDay   = dt.datetime(2017,6,27,0,0)
    duration = endDay-startDay
    daysUsers = np.zeros((duration.days,len(usercreated)+1))
    daysUsersEnrolled = np.zeros((1,duration.days))[0]
    for i in range(duration.days):
        for it in ans:
            dur = it[2]-startDay
            if(dur.days == i):
                daysUsers[i,it[1]] = 1
        t=0
        for j in range(len(usercreated)):
            if((usercreated[j]-startDay).days<=i):
                t+=1
        daysUsersEnrolled[i] = t
    vec = np.sum(daysUsers,axis=1)
    sns.set()
    sns.set_style("ticks")
    p = sns.barplot(list(range(duration.days)),daysUsersEnrolled,
            color=(186/255,214/255,234/255), label='Enrolled')
    ax1 = p.axes
    for i,pp in enumerate(p.patches):
        #Set hatch for Satudays and Sundays
        if((i-5)%7==0 or (i-6)%7==0):
            pp.set_edgecolor((1,1,1,1))
            pp.set_hatch('//')
            pp.set_label('Enrolled (Weekend)')
        #Set hatch for public holidays
        if(i==3 or i==14):
            pp.set_edgecolor((1,1,1,1))
            pp.set_hatch('\\\\')
            pp.set_label('Enrolled (Holiday)')
    ax1.set_yticks([20,40,60,80,100,120])
    ax1.set_yticklabels([20,40,60,80,100,120], fontsize=14)
    ax1.set_xticks(range(0,36,5))
    ax1.set_xticklabels(range(0,36,5), fontsize=14)
    ax1.plot(range(len(vec)),vec,color=(42/255,122/255,185/255),label='Active')
    ax1.plot([0, duration.days-1], [np.mean(vec), np.mean(vec)],
            '--',color=(83/255,157/255,204/255), label='Active (avg)')
    ax1.set_xlim([0,35.5])
    ax1.set_xlabel('Day', fontweight='bold', fontsize=14)
    ax1.set_ylabel('Number of users', fontweight='bold', fontsize=14)
    ax1.set_position([0.09, 0.12, 0.90, 0.87])
    sns.despine()
    plt.legend()
    h, l = ax1.get_legend_handles_labels()
    plt.legend([h[-1],h[3],h[2],h[0],h[1]], [l[-1],l[3],l[2],l[0],l[1]],
            fontsize=14,loc=1,bbox_to_anchor=(0.99,0.94),frameon=True,facecolor=(1,1,1),edgecolor=(1,1,1))
    pcf = plt.gcf()
    pcf.set_figwidth(9)
    pcf.set_figheight(5)
    if cf.SAVE_FIGS:
        plt.savefig('img/fig1.pdf')
    if cf.SHOW_FIGS:
        plt.show()
    else:
        plt.close('all')

def fig2(ans):
    class_names = ['News', 'Sport', 'Movie', 'Series', 'Music', 
                   'Doc', 'Entert', 'Child', 'User', 'Other','None']
    class_count = np.zeros((1,len(class_names)))[0]
    for it in ans:
        if it[6] is not None:
            for it2 in it[6]:
                if(len(it2)==1 and it2!='x'):
                    class_count[int(it2)-1] += 1
                elif(it2=='x'):
                    class_count[-2] += 1
        else:
            class_count[-1] += 1
    sns.set()
    sns.set_style("ticks")
    fig, ax = plt.subplots(1,2,False,False)
    ax[0].bar(range(len(class_count)-1),class_count[:-1],
              color=(42/255,122/255,185/255))
    ax[0].set_xticks(range(len(class_count)-1))
    ax[0].set_xticklabels(class_names[:-1], fontsize=14)
    ax[0].set_xlim([-1,len(class_count)-1])
    ax[0].set_ylim([0,900])
    ax[0].set_yticks([200,400,600,800])
    ax[0].set_yticklabels([200,400,600,800], fontsize=14)
    ax[0].set_ylabel('Number of answers',fontweight='bold', fontsize=14)
    ax[0].text(4.5,-120,'Q4 (Genre)',ha='center',
               fontweight='bold',fontsize=14)
    ax[1].bar(range(2),[sum(class_count[:-1]),class_count[-1]],
            color=(42/255,122/255,185/255))
    ax[1].set_xlim([-1,2])
    ax[1].set_xticks(range(2))
    ax[1].set_xticklabels(['Yes', 'No'], fontsize=14)
    ax[1].set_ylim([0,4500])
    ax[1].set_yticks([1000,2000,3000,4000])
    ax[1].set_yticklabels([1000,2000,3000,4000], fontsize=14)
    ax[1].yaxis.tick_right()
    ax[0].text(11.25,-120,'Q1 (Seen TV?)',ha='center',
               fontweight='bold',fontsize=14)
    ax[0].yaxis.grid()
    ax[1].yaxis.grid()
    sns.despine(ax=ax[0], right=True, left=False)
    sns.despine(ax=ax[1], left=False, right=False)
    fig.set_figwidth(10)
    fig.set_figheight(5)
    ax[0].set_position([0.08, 0.12, 0.70, 0.87])
    ax[1].set_position([0.78, 0.12, 0.15, 0.87])
    if cf.SAVE_FIGS:
        plt.savefig('img/fig2.pdf')
    if cf.SHOW_FIGS:
        plt.show()
    else:
        plt.close('all')

def fig3_1(ans):
    lab = ['ansid', 'userid', 'timestamp', 'tv', 
           'who', 'many', 'what', 'where', 'attention']
    df  = pd.DataFrame.from_records(ans,columns=lab)
    sns.set()
    sns.set_style("ticks")
    fig = plt.figure(figsize=(10,5), dpi=200)
    ax1 = plt.Axes(fig, [0.07, 0.12, 0.92, 0.84])
    fig.add_axes(ax1)
    class_names = ['News', 'Sport', 'Movie', 'Series', 'Music', 
                   'Doc', 'Entert', 'Child', 'User', 'Other']
    sns.factorplot(x="what", y="attention", data=df, kind="bar",
            estimator=np.mean, ci="sd", color=(42/255,122/255,185/255),ax=ax1)
    ax1.set_xticks(range(10))
    ax1.set_xticklabels(class_names,fontsize=14)
    ax1.set_xlabel('Q4 (Genre)',fontweight='bold',fontsize=14)
    ax1.set_ylabel('Q6 (Attention level)',fontweight='bold',fontsize=14)
    ax1.yaxis.grid()
    plt.close()
    sns.despine(ax=ax1)
    plt.yticks(range(1,6),['1', '2', '3', '4', '5'],fontsize=14)
    ax1.text(-0.55, 1.19,'(None)',ha='right',va='center',fontsize=14)
    ax1.text(-0.6, 4.75,'(Full)',ha='right',va='center',fontsize=14)
    plt.ylim([1,5])
    if cf.SAVE_FIGS:
        plt.savefig('img/fig3_1.pdf')
    if cf.SHOW_FIGS:
        plt.show()
    else:
        plt.close('all')

def fig3_2(ans):
    lab = ['ansid', 'userid', 'timestamp', 'tv', 
           'who', 'many', 'what', 'where', 'attention']
    df  = pd.DataFrame.from_records(ans,columns=lab)
    sns.set()
    sns.set_style("ticks")
    fig = plt.figure(figsize=(10,5), dpi=200)
    ax1 = plt.Axes(fig, [0.07, 0.12, 0.92, 0.84])
    fig.add_axes(ax1)
    class_names = ['News', 'Sport', 'Movie', 'Series', 'Music', 
                   'Doc', 'Entert', 'Child', 'User', 'Other']
    sns.factorplot(x="what", y="many", data=df, kind="bar",
            estimator=np.mean, ci="sd", color=(42/255,122/255,185/255),ax=ax1)
    ax1.set_xticks(range(10))
    ax1.set_xticklabels(class_names,fontsize=14)
    ax1.set_xlabel('Q4 (Genre)',fontweight='bold',fontsize=14)
    ax1.set_ylabel('Q3 (Number of viewers)',fontweight='bold',fontsize=14)
    sns.despine(ax=ax1)
    ax1.set_yticks(range(1,6))
    ax1.set_yticklabels(range(1,6),fontsize=14)
    ax1.set_ylim([1,3.75])
    ax1.yaxis.grid()
    plt.close()
    if cf.SAVE_FIGS:
        plt.savefig('img/fig3_2.pdf')
    if cf.SHOW_FIGS:
        plt.show()
    else:
        plt.close('all')

def fig4(ans):
    lab = ['ansid', 'userid', 'timestamp', 'tv', 
           'who', 'many', 'what', 'where', 'attention']
    df  = pd.DataFrame.from_records(ans,columns=lab)
    df['social'] = df.apply (lambda row: social_or_not(row),axis=1)
    df['time'] = df.apply (lambda row: time_of_day(row),axis=1)
    df['day'] = df.apply (lambda row: weekday_end_holiday(row),axis=1)
    colors = ((42/255,122/255,185/255),(186/255,214/255,234/255))
    sns.set()
    sns.set_style("ticks")
    grouped = df.groupby(['day', 'social'], sort=False)
    time_counts = grouped['time'].value_counts(normalize=True, sort=False)
    time_data = [
        {'time': time, 'day': day, 'social': social, 'percentage': percentage*100} for
        (day, social, time), percentage in dict(time_counts).items()
    ]
    df_time = pd.DataFrame(time_data)
    p = sns.factorplot(x="time", y="percentage", hue="day", 
            col="social", data=df_time, kind="bar", 
            legend_out=False, palette=colors)
    ax1 = p.axes[0][0]
    ax2 = p.axes[0][1]
    ax1.set_xticks(range(5))
    ax1.set_xticklabels(['Morning', 'Noon', 'Afternoon', 'Evening', 'Night'],fontsize=14)
    ax2.set_xticklabels(['Morning', 'Noon', 'Afternoon', 'Evening', 'Night'],fontsize=14)
    ax1.set_ylim([0, 39.89])
    ax1.set_yticklabels(range(0,40,5),fontsize=14)
    ax1.set_xlabel('Time of day',fontweight='bold',fontsize=14)
    ax2.set_xlabel('Time of day',fontweight='bold',fontsize=14)
    ax1.set_ylabel('Percentage of observations',fontweight='bold',fontsize=14)
    ax1.title.set_text('Alone')
    ax2.title.set_text('Social')
    ax1.title.set_fontweight('bold')
    ax2.title.set_fontweight('bold')
    ax1.title.set_fontsize(15)
    ax2.title.set_fontsize(15)
    l1 = ax1.legend(loc=2,fontsize=11)
    l2 = ax2.legend(loc=2,fontsize=11)
    l1.set_title('')
    l2.set_title('')
    grouped = df.groupby(['social'])
    day_counts = grouped['day'].value_counts()
    l1.get_texts()[0].set_text('Weekday (N={})'.format(day_counts[1][0]))
    l1.get_texts()[1].set_text('Weekend/holiday (N={})'.format(day_counts[1][1]))
    l2.get_texts()[0].set_text('Weekday (N={})'.format(day_counts[2][0]))
    l2.get_texts()[1].set_text('Weekend/holiday (N={})'.format(day_counts[2][1]))
    ax1.yaxis.grid()
    ax2.yaxis.grid()
    ax1.set_position([0.07, 0.12, 0.45, 0.83])
    ax2.set_position([0.54, 0.12, 0.45, 0.83])
    p.fig.set_figwidth(10)
    p.fig.set_figheight(5)
    grouped = df.groupby(['social', 'day'], sort=False)
    genre_counts = grouped['time'].value_counts(normalize=False, sort=False)
    i=0
    for pp in ax1.patches:
        height = pp.get_height()
        ax1.text(pp.get_x()+pp.get_width()/2.+((i>5)*1-0.5)*0.1,
                height + 0.25,
                '{}'.format(genre_counts[1][i]),
                fontsize=14,
                ha="center")
        i+=1
    i=0
    for pp in ax2.patches:
        height = pp.get_height()
        ax2.text(pp.get_x()+pp.get_width()/2.+((i>5)*1-0.5)*0.1,
                height + 0.25,
                '{}'.format(genre_counts[2][i]),
                fontsize=14,
                ha="center")
        i+=1
    if cf.SAVE_FIGS:
        plt.savefig('img/fig4.pdf')
    if cf.SHOW_FIGS:
        plt.show()
    else:
        plt.close('all')

def fig5(ans):
    lab = ['ansid', 'userid', 'timestamp', 'tv', 
           'who', 'many', 'what', 'where', 'attention']
    df  = pd.DataFrame.from_records(ans,columns=lab)
    df['social'] = df.apply (lambda row: social_or_not(row),axis=1)
    df['time'] = df.apply (lambda row: time_of_day(row),axis=1)
    df['day'] = df.apply (lambda row: weekday_end_holiday(row),axis=1)
    colors = ((42/255,122/255,185/255),(186/255,214/255,234/255))
    sns.set()
    sns.set_style("ticks")
    p = sns.factorplot(x="time", y="attention", hue='day', 
            col='social', data=df, kind="bar", estimator=np.mean, 
            ci="sd", legend_out=False, palette=colors)
    ax1 = p.axes[0][0]
    ax2 = p.axes[0][1]
    ax1.set_xticks(range(5))
    ax1.set_xticklabels(['Morning', 'Noon', 'Afternoon', 'Evening', 'Night'],fontsize=14)
    ax2.set_xticklabels(['Morning', 'Noon', 'Afternoon', 'Evening', 'Night'],fontsize=14)
    ax1.set_yticks(range(1,6))
    ax1.set_yticklabels(['1', '2', '3', '4', '5'],fontsize=14)
    ax1.set_ylim([1, 5])
    ax1.set_xlabel('Time of day',fontweight='bold',fontsize=14)
    ax2.set_xlabel('Time of day',fontweight='bold',fontsize=14)
    ax1.set_ylabel('Q6 (Attention level)',fontweight='bold',fontsize=14)
    ax1.title.set_text('Alone')
    ax2.title.set_text('Social')
    ax1.title.set_fontweight('bold')
    ax2.title.set_fontweight('bold')
    ax1.title.set_fontsize(15)
    ax2.title.set_fontsize(15)
    ax1.text(-0.55, 1.19,'(None)',ha='right',va='center',fontsize=14)
    ax1.text(-0.6, 4.75,'(Full)',ha='right',va='center',fontsize=14)
    l1 = ax1.legend(loc=4,frameon=True,facecolor=(1,1,1),edgecolor=(1,1,1),fontsize=12)
    l2 = ax2.legend(loc=4,frameon=True,facecolor=(1,1,1),edgecolor=(1,1,1),fontsize=12)
    l1.set_title('')
    l2.set_title('')
    ax1.yaxis.grid()
    ax2.yaxis.grid()
    ax1.set_position([0.07, 0.12, 0.45, 0.83])
    ax2.set_position([0.54, 0.12, 0.45, 0.83])
    p.fig.set_figwidth(10)
    p.fig.set_figheight(5)
    if cf.SAVE_FIGS:
        plt.savefig('img/fig5.pdf')
    if cf.SHOW_FIGS:
        plt.show()
    else:
        plt.close('all')

def fig6(ans):
    lab = ['ansid', 'userid', 'timestamp', 'tv', 
           'who', 'many', 'what', 'where', 'attention']
    df  = pd.DataFrame.from_records(ans,columns=lab)
    df['social'] = df.apply (lambda row: social_or_not(row),axis=1)
    df['day'] = df.apply (lambda row: weekday_end_holiday(row),axis=1)
    sns.set()
    sns.set_style("ticks")
    class_names = ['News', 'Sport', 'Movie', 'Series', 'Music', 
                   'Doc', 'Entert', 'Child', 'User', 'Other']
    colors = ((42/255,122/255,185/255),(186/255,214/255,234/255))
    grouped = df.groupby(['day', 'social'], sort=False)
    genre_counts = grouped['what'].value_counts(normalize=True, sort=False)
    genre_data = [
        {'what': what, 'day': day, 'social': social, 'percentage': percentage*100} for
        (day, social, what), percentage in dict(genre_counts).items()
    ]
    df_genre = pd.DataFrame(genre_data)
    p = sns.factorplot(x="what", y="percentage", hue="day", 
            col="social", kind="bar", data=df_genre, 
            legend_out=False, palette=colors)
    ax1 = p.axes[0][0]
    ax2 = p.axes[0][1]
    ax1.set_xticks(range(10))
    ax1.set_xticklabels(class_names)
    ax1.set_xlabel('Q4 (Genre)',fontweight='bold')
    ax2.set_xlabel('Q4 (Genre)',fontweight='bold')
    ax1.set_ylabel('Percentage of observations',fontweight='bold')
    ax1.title.set_text('Alone')
    ax2.title.set_text('Social')
    ax1.title.set_fontweight('bold')
    ax2.title.set_fontweight('bold')
    l1 = ax1.legend()
    l2 = ax2.legend()
    l1.set_title('')
    l2.set_title('')
    grouped = df.groupby(['social'])
    day_counts = grouped['day'].value_counts()
    l1.get_texts()[0].set_text('Weekday (N={})'.format(day_counts[1][0]))
    l1.get_texts()[1].set_text('Weekend/holiday (N={})'.format(day_counts[1][1]))
    l2.get_texts()[0].set_text('Weekday (N={})'.format(day_counts[2][0]))
    l2.get_texts()[1].set_text('Weekend/holiday (N={})'.format(day_counts[2][1]))
    ax1.yaxis.grid()
    ax2.yaxis.grid()
    ax1.set_position([0.04, 0.12, 0.46, 0.83])
    ax2.set_position([0.53, 0.12, 0.46, 0.83])
    p.fig.set_figwidth(15)
    p.fig.set_figheight(5)
    grouped = df.groupby(['social', 'day'], sort=False)
    genre_counts = grouped['what'].value_counts(normalize=False, sort=False)
    i=0
    for pp in ax1.patches:
        height = pp.get_height()
        ax1.text(pp.get_x()+pp.get_width()/2.,
                height + 0.25,
                '{}'.format(genre_counts[1][i]),
                fontsize=10,
                ha="center")
        i+=1
    i=0
    for pp in ax2.patches:
        height = pp.get_height()
        ax2.text(pp.get_x()+pp.get_width()/2.,
                height + 0.25,
                '{}'.format(genre_counts[2][i]),
                fontsize=10,
                ha="center")
        i+=1
    if cf.SAVE_FIGS:
        plt.savefig('img/fig6.pdf')
    if cf.SHOW_FIGS:
        plt.show()
    else:
        plt.close('all')

def time_of_day(ts):
    """Bin the timestamp into five (morning,noon,afternoon,evening,night)."""
    h=ts['timestamp'].hour
    t=0
    #Morning
    if(h >= 6 and h <= 9):
        t=1
        # t='Morning'
    #Noon
    elif(h > 9 and h <= 13):
        t=2
        # t='Noon'
    #Afternoon
    elif(h > 13 and h <= 17):
        t=3
        # t='Afternoon'
    #Evening
    elif(h > 17 and h <= 21):
        t=4
        # t='Evening'
    #Night
    else:
        t=5
        # t='Night'
    return t

def weekday_end(ts):
    """Bin the timestamp into two (weekday,weekend)."""
    weekday = ts['timestamp'].weekday() #Monday == 0 ... Sunday == 6
    t=0
    if(weekday<5): #Split to weekday / weekend
        # t=1
        t='Weekday'
    else:
        # t=2
        t='Weekend'
    return t

def weekday_end_holiday(ts):
    """Bin the timestamp into two (weekday,weekend/holiday)."""
    ts = ts['timestamp']
    weekday = ts.weekday() #Monday == 0 ... Sunday == 6
    d = ts.day
    m = ts.month
    t=0
    if(weekday<5): #Weekday
        t='Weekday'
        if(m==5 and d==25): #Ascension Thursday
            t='Weekend/holiday'
        if(m==6 and d==5 ): #Whit Monday
            t='Weekend/holiday'
    else:
        t='Weekend/holiday'
    return t

def weekday_end_holiday_1_2(ts):
    """Bin the timestamp into two (weekday,weekend/holiday)."""
    ts = ts['timestamp']
    weekday = ts.weekday() #Monday == 0 ... Sunday == 6
    d = ts.day
    m = ts.month
    t=0
    if(weekday<5): #Weekday
        t=1
        if(m==5 and d==25): #Ascension Thursday
            t=2
        if(m==6 and d==5 ): #Whit Monday
            t=2
    else:
        t=2
    return t

def social_or_not(ts):
    t=0
    if(ts['many']==1): #Split to weekday / weekend
        t=1
    else:
        t=2
    return t

def association_of_features(ans):
    lab = ['ansid', 'userid', 'timestamp', 'tv', 
           'who', 'many', 'what', 'where', 'attention']
    df  = pd.DataFrame.from_records(ans,columns=lab)
    df['time'] = df.apply (lambda row: time_of_day(row),axis=1)
    df['day'] = df.apply (lambda row: weekday_end_holiday_1_2(row),axis=1)

    #Uncomment feature 1
    f1 = list(list(zip(*ans))[6]);  d1=9;  f1_name='Genre'
    # f1 = list(df['time']);          d1=5;   f1_name='Time of day'
    # f1 = list(df['day']);           d1=2;   f1_name='Weekday'
    # f1 = list(list(zip(*ans))[5]);  d1=5;   f1_name='Many'
    # f1 = list(list(zip(*ans))[8]);  d1=5;   f1_name='Attention'

    #Uncomment feature 2
    # f2 = list(df['time']);          d2=5;   f2_name='Time of day'
    # f2 = list(df['day']);           d2=2;   f2_name='Weekday'
    # f2 = list(list(zip(*ans))[4]);  d2=8;   f2_name='Who'
    # f2 = list(list(zip(*ans))[5]);  d2=5;   f2_name='Many'
    # f2 = list(list(zip(*ans))[7]);  d2=8;   f2_name='Service'
    f2 = list(list(zip(*ans))[8]);  d2=5;   f2_name='Attention'

    #Find and remove None elements
    idx = list(range(len(f1)))
    for i in range(len(f1)):
        if f1[i] is None or f2[i] is None:
            idx.remove(i)
        if f1[i] == 10: #Remove "other"
            idx.remove(i)
    f1 = [f1[i] for i in idx]
    f2 = [f2[i] for i in idx]
    #Compute contingency table
    mat = np.zeros((d1,d2))
    for i in range(len(f1)):
        if isinstance(f2[i],int):
            mat[f1[i]-1,f2[i]-1] += 1
        else:
            for it in f2[i]:
                mat[f1[i]-1,it-1] += 1
    #Compute chi-square
    chi2, p, dof, exp = scipy.stats.chi2_contingency(mat)
    #Compute Cramer's V based on the chi-square
    cramersV = np.sqrt(chi2/(np.sum(mat)*(min(mat.shape)-1)))
    #Compute bias corrected Cramer's V, source:
    #W. Bergsma (2013), "A bias correction for Cramér's V and Tschuprow's T".
    r,k = mat.shape
    phi2corr = max(0, chi2/np.sum(mat) - ((k-1)*(r-1))/(np.sum(mat)-1))
    rcorr = r - ((r-1)**2)/(np.sum(mat)-1)
    kcorr = k - ((k-1)**2)/(np.sum(mat)-1)
    cramersVcor = np.sqrt(phi2corr / min((kcorr-1), (rcorr-1)))
    #Print results
    print('Association between the two features f1 and f2')
    print('f1:', f1_name, ', f2:', f2_name)
    print('Contingency table:')
    print(mat)
    print('Expected frequencies (over 5: {0:.1f}%):'.format(100*np.sum(exp>5)/(r*k)))
    np.set_printoptions(precision=0)
    print(exp)
    print('chi2: ', chi2)
    print('dof:  ', dof)
    print('p:    ', p)
    print('crV:  ', cramersV)
    print('crVc: ', cramersVcor)
