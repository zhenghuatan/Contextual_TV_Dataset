import numpy as np
#Check if it's possible to show figures (server compability)
import matplotlib as mpl
from subprocess import DEVNULL, check_call, CalledProcessError
try:
    callstr=['python','-c','import matplotlib.pyplot as plt;print(plt.show())']
    check_call(callstr, stdout=DEVNULL, stderr=DEVNULL)
except CalledProcessError:
    mpl.use('agg')

#Import "homemade" tools
import src.read_tools as rd
import src.analysis_tools as an
import src.predict_labels as pl
import src.config as cf

if __name__ == "__main__": 
    #Choose if figures should be saved/shown
    cf.SAVE_FIGS = True #Default is False
    if not mpl.get_backend() == 'agg': #Check if it's even possible to show
        cf.SHOW_FIGS = False #Default is False

    ###Pre-processing
    #Seed random generator
    np.random.seed(100)
    #File containing answers
    fp = 'data/answers.csv'
    #Read csv file and get all answers
    answ = rd.read_answers_csv(fp) 
    #Get yes answers
    ans = rd.get_yes_answers(answ)
    #Clean answers for text
    ans = rd.clean_answers_for_text(ans)
    #Split answers 
    ans = rd.split_answers(ans)
    #File containing user info
    fp = 'data/users.csv'
    #Read info for each user
    users = rd.read_user_data(fp)


    ###Generate plots
    an.fig1(answ, users)
    an.fig2(answ)
    an.fig3_1(ans)
    an.fig3_2(ans)
    an.fig4(ans)
    an.fig5(ans)
    an.fig6(ans)

    ###Chi-square test of association between features
    #(see function to edit which features)
    an.association_of_features(ans)


    ###Prediction
    run_prediction = True
    if run_prediction:
        #Choose whether to save confusion matrix
        cf.SAVE_CONFMAT  = True
        #Choose whether to perform McNemar's test
        cf.MCNEMAR_TESTS = [
                            ['LR_TD',    'LR_TDW'],
                            # ['LR_TD',    'LR_WA'],
                            # ['LR_WA',    'LR_TDW'],
                            # ['LR_TDW',   'LR_all-U'],
                            ['LR_all-U', 'LR_U'    ],
                            # ['LR_U',     'LR_UTD'  ],
                            ['LR_UTD',   'LR_UWA'  ],
                            ['LR_UWA',   'LR_all'  ],
                            # ['LR_all',   'LR_all+S'],
                           ]
        #Convert each raw answer to a feature vector
        answers_feat = rd.make_feat_vec(ans)
        #Get the users that have answered at least 5 times and remove others
        answers_feat, active_users = rd.get_active_users(answers_feat,5)
        #Select feature configurations that should be tested
        features = [
                    'TD',
                    'WA',
                    'TDW',
                    'all-U', 
                    'U',
                    'UTD',
                    'UWA',
                    'all', #all: UTDWMA
                    'all+S', 
                    ]
        #Select methods that should be tested
        methods  = [
                    'random',
                    'toppop',
                    'LR',
                    'GBDT',
                    'SVM',
                    'MLP',
                    ]
        #Select metrics for testing
        metrics  = [
                    'A@1',
                    'A@3',
                    'F1 (macro)',
                    'MRR',
                    ]
        #Run test
        pl.predict_labels(answers_feat,active_users,features,methods,metrics)
