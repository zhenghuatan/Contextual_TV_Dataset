# Contextual TV Dataset
This project contains TV consumption data (enriched with contextual information) collected using the Experience-Sampling Method (ESM) from approx. 120 participants during a five week period. The data is located in the [data/](data/) folder.

## Analysis
The aim of the code provided here is to analyse the data using plots of various feature interactions. Each plot is produced from a function call in *data_analysis.py*. The actual code for each function is located [in this file](src/analysis_tools.py). The resulting plots will be located in the [img/](img/) folder.
